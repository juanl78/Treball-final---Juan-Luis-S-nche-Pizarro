package ClasesHeredadas;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import ClasesHeredadas.Alumno;

public class Control {
	
	
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		
		List<Reserva> lsReserva=new ArrayList<>(); 
		Colegio colegio=new Colegio();//objeto de tipo Colegio para 
		
		int op;
			
		do {
			System.out.print("INTRODUCE UN 1 para a�adir personas, 2 hacer reserva , 0 para salir");
			op= teclado.nextInt();
			
			switch (op) {
			
			
			case 1:
				
				 colegio.addPersonas();
	
				break;
				
			case 2:
				
				
				lsReserva.add(Reserva.reserva(colegio));
				
				
				
				break;

			case 3:
				
			
				
				
				break;	
				
			case 4:
				
		
				
				
		
				break;	
				
			case 5:
				
				//Venta v=Venta.adjudicarVenta(lsPersonas,listaDisponibles); //Venta v viene del return 
				
				//lsVentas.add(v);//aqui a�adimos la venta que viene de return a la lista de ventas 
				
				
				
				break;
				
				}
			
		}while(op!=0);
		//MIENTRAS EL WHILE INTRODUCIMOS VALORES DISTINTOS DE CERO SE EJECUTA EL DO
		
		
}
	
	
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

