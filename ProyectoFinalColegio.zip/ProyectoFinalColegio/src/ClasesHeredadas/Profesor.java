package ClasesHeredadas;

import java.util.Scanner;

public class Profesor extends Persona {
	
	private String especialidad;

	public Profesor(String nombre, Integer edad, String dni, String especialidad) {
		super(nombre, edad, dni);
		this.especialidad = especialidad;
	}

	
	
	//creamos un constructor para Profesor pero en este los atributos relativos a Persona se los pasamos con un objeto de tipo Persona (Como si fuera un conjunto de datos)
	public Profesor(Persona p,  String especialidad) {	
		//(Persona p,=lleva los atributos de la clase persona.
		super(p.getNombre(), p.getEdad(), p.getDni());//lo usaremos en el programa y cogeremos la informaci�n de persona
		this.especialidad = especialidad;
		
	}
	/*
	 * Caso hipotetico
	 * Persona pers = new Persona ("juan", "45", "65566666");
	 * 
	 */
	
	
	public Profesor(Persona p) {//super no esta vac�o lo coge der la clase persona y los demas atributos de la clase usuario los inicializo a nulo
		
		super(p.getNombre(), p.getEdad(), p.getDni());
		this.especialidad = null;
	
	}
	
	
	public Profesor() {
		
		super();   //super constructor al no tener getNombre,que coge la informaci�n de la clase persona,lo inicializo a vac�o porque me interesa
		this.especialidad = null;
		
	}



	public String getEspecialidad() {
		return especialidad;
	}



	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}





	@Override
	public String toString() {
		return "Profesor [especialidad=" + especialidad + ", datos basicos de persona " + super.toString() + "]";
	}



	//si lo hacemos no static podrimaos acceder al por ejemplo al alumno2 seria el invocador 
	public static Profesor addPersonas() {  //ojo al ser abstracta no podemos poner static
		Profesor user1 = new Profesor();// creas un objeto nuevo de tipo usuario constructor vacio
		Scanner teclado= new Scanner (System.in); 
		
		System.out.print("DAME EL NOMBRE " ); 
		//this.getNombre();  
	    user1.setNombre(teclado.next());  
	    
	    System.out.print("DAME LA EDAD" );  
	    user1.setEdad(teclado.nextInt());
	    
	    System.out.print("DAME EL dni" );    
	    user1.setDni(teclado.next());
	    
	    System.out.print("DAME la especialidad" );         
	    user1.setEspecialidad(teclado.next());
		
		
	
		return user1;
	}
	
	
	
	
	
	
	
}
