package ClasesHeredadas;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Reserva {

	
	private Profesor profesor;
    private Trabajador trabajador;
    private Alumno alumno;
	private Date fecha;
	private Time hora;
	

public Reserva(Profesor profesor, Date fecha, Time hora) {
		super();
		this.profesor = profesor;
		this.fecha = fecha;
		this.hora = hora;
	}



public Reserva(Trabajador trabajador, Date fecha, Time hora) {
	super();
	this.trabajador = trabajador;
	this.fecha = fecha;
	this.hora = hora;
}

	
	

public Profesor getProfesor() {
	return profesor;
}



public void setProfesor(Profesor profesor) {
	this.profesor = profesor;
}



public Trabajador getTrabajador() {
	return trabajador;
}



public void setTrabajador(Trabajador trabajador) {
	this.trabajador = trabajador;
}



public Alumno getAlumno() {
	return alumno;
}



public void setAlumno(Alumno alumno) {
	this.alumno = alumno;
}



public Reserva(Alumno alumno, Date fecha, Time hora) {
		super();
		this.alumno = alumno;
		this.fecha = fecha;
		this.hora = hora;
	}


	


public Reserva() {
	super();
	
}



public Date getFecha() {
	return fecha;
}



public void setFecha(Date fecha) {
	this.fecha = fecha;
}



public Time getHora() {
	return hora;
}



public void setHora(Time hora) {
	this.hora = hora;
}





@Override
public String toString() {
	String res = "Reserva [";
	if(profesor != null ) {
		res +=  "profesor=" + profesor;
	} 
	if (trabajador != null) {
		res +=  ", trabajador=" + trabajador;
	}
	if(alumno != null ) {
		res += ", alumno=" + alumno;
	}
	
	return res +=  ", fecha=" + fecha
			+ ", hora=" + hora + "]";
	
}



public static Reserva reserva(Colegio colegio ) {//le pasamos el objeto colegio que contiene todos los atributos para filtrar
	
	//en el colegio llevo la listacompleta 
	Reserva reserva=null;  //objeto no inicializado
	
	Scanner teclado= new Scanner (System.in); 
	
	System.out.println("0: busca por lista alumno , 1: busca  profesor en la lista,2 :busca  trabajador en la lista");
	int opt = teclado.nextInt();
	
    if (opt==0){
      
    	System.out.println("Dame el nombre");
    	String name  = teclado.next();
    	System.out.println("Dame el dni");
    	String dni = teclado.next();
    	  
     
    	
    	List<Persona> alumno = colegio.getListaCompleta(); //cojemos la lista de personas 	List<Persona> alumno y colegio seria donde cogemos la lista
    	
    	//t->t instanceof alumno preguntamos si es elemento pertenece a la clase Alumno
    	                                                               //(t -> ((Alumno)t)  es de la lista de alumno no existe porque es de persona 
    	alumno=alumno.stream().filter(t->t instanceof Alumno).filter(t -> ((Alumno)t).getNombre().equals(name)  //filtramos por clase alumno
    			&& ((Alumno)t).getDni().equals(dni)).collect(Collectors.toList());
    	
    	Alumno alumno1 = alumno.size() > 0 ? (Alumno) alumno.get(0) : null;//sino encuentra alumno1=null y si encuentra coje la primera posici�n
                                                     //al coger get(0)el primer objeto se genera el mismo
       //System.out.println(alumno);
    	reserva= new Reserva(alumno1,new Date(System.currentTimeMillis()), new Time(System.currentTimeMillis()));//inicializo el objeto tercer  caso caso
    	
    
   

    }else if(opt == 1) {
    	
    	System.out.println("Dame el nombre");
    	String name  = teclado.next();
    	System.out.println("Dame el dni");
    	String dni = teclado.next();
    	
      
    	//filtramos por la clase persona y seleccionamos alumno para 
    	
    	List<Persona> profesor = colegio.getListaCompleta(); //cojemos la lista de personas 	List<Persona> alumno y colegio seria donde cogemos la lista
    	
    	 profesor=profesor.stream().filter(t-> t instanceof Profesor).filter(t ->t.getNombre().equals(name)  //filtramos por clase alumno
    			&& t.getDni().equals(dni)).collect(Collectors.toList());
    	
    	 	
     	Profesor profesor1 = profesor.size() > 0 ? (Profesor) profesor.get(0) : null;//sino encuentra alumno1=null y si encuentra coje la primera posici�n
                                                      //al coger get(0)el primer objeto se genera el mismo
        //System.out.println(alumno);
     	reserva= new Reserva(profesor1,new Date(System.currentTimeMillis()), new Time(System.currentTimeMillis()));//inicializo el objeto tercer  caso caso
     	 
     
    	 
 
      
      
    }else if(opt == 2) {
    	
    
    	System.out.println("Dame el nombre");
    	String name  = teclado.next();
    	System.out.println("Dame el dni");
    	String dni = teclado.next();
    	
      
    	//filtramos por la clase persona y seleccionamos alumno para 
    	
    	List<Persona> trabajador = colegio.getListaCompleta(); //cojemos la lista de personas 	List<Persona> alumno y colegio seria donde cogemos la lista
    	
    	 trabajador=trabajador.stream().filter(t -> t instanceof Trabajador && t.getNombre().equals(name)  //filtramos por clase alumno
    			&& t.getDni().equals(dni)).collect(Collectors.toList());
    	
    	 	
      	Trabajador  trabajador1 = trabajador.size() > 0 ? (Trabajador) trabajador.get(0) : null;//sino encuentra alumno1=null y si encuentra coje la primera posici�n
                                                       //al coger get(0)el primer objeto se genera el mismo
         //System.out.println(alumno);
      	reserva= new Reserva(trabajador1,new Date(System.currentTimeMillis()), new Time(System.currentTimeMillis()));//inicializo el objeto tercer  caso caso      	 
     	 
    }
    System.out.println(reserva);
    return reserva;
	
   
    
	 
	
}

}


