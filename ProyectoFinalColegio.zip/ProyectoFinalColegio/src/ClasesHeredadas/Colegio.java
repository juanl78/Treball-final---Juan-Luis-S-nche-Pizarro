package ClasesHeredadas;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.FactoryConfigurationError;


public class Colegio {

	private String nombre;
	private List<Persona>listaCompleta;  //la lista de personas lleva profesores, alumnos y  trabajadores 
	
	public Colegio() {
		listaCompleta=new ArrayList<>();
	
	}

	public Colegio(String nombre, List<Persona> listaCompleta) {
		super();
		this.nombre = nombre;
		this.listaCompleta = listaCompleta;
	}

	

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Persona> getListaCompleta() {
		return listaCompleta;
	}

	public void setListaCompleta(List<Persona> listaCompleta) {
		this.listaCompleta = listaCompleta;
	}

	@Override
	public String toString() {
		return "Colegio [nombre=" + nombre + ", ListaCompleta=" + listaCompleta + "]";
	}
	
	
   public void addPersonas() {  //esto a�ade a la listaCompleta todos los alumnos,profes y tarbajadores
		
	   //el static no conoce ninguna lista en concreto y el no static conoce la lista del invocador,porque estamos dentro de la misma clase
	   //si tenemos que a�adir objeto de tipo alumno,trabajador o profesor en un metodo si es static deberemos pasarle al metodo la listaCompleta
		//a�ado los alumno,profesores y trabajadores en listaCompleta
		
		Scanner teclado= new Scanner (System.in); 
		
		System.out.println("0: para crear alumno , 1: para crear profesor,2 :crear trabajador ");
		int opt = teclado.nextInt();
		
		
		
	    if (opt==0){
	        //list es abstracta no puedes invicarla con new
	    	//List<Persona>listaCompleta=new ArrayList<>();
	    //Alumno alumno= new Alumno();   //creamos el objeto 
	    listaCompleta.add(Alumno.addPersonas());  //aqui a�ado lo del metodo addpersona de alumno a la listaCompleta estan relacionados ya que
	                                             //tenemos 3 opciones de a�adir a la lista 
	    System.out.println(listaCompleta);
	
	    }else if(opt == 1) {
		
	      listaCompleta.add(Profesor.addPersonas());
	      System.out.println(listaCompleta);
	     
		//for(int i=0; i<listaCompleta.size(); i++) {
	    	  
	    	 // Persona p=listaCompleta.get(i);
	    	  
	    	 // System.out.println(p);   
	      //}
	  
	      
	      
        }else if(opt == 2) {
        	
        listaCompleta.add(Trabajador.addPersonas());	
        System.out.println(listaCompleta);   
        }
	
        
	
}
}
