package ClasesHeredadas;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Alumno extends Persona {
	private String aula;

	public Alumno(String nombre, Integer edad, String dni, String aula) {
		super(nombre, edad, dni);
		this.aula = aula;
	}

	
	//creamos un constructor para alumno pero en este los atributos relativos a Persona se los pasamos con un objeto de tipo Persona (Como si fuera un conjunto de datos)
	public Alumno(Persona p, String aula) {
			
		//(Persona p,=lleva los atributos de la clase persona.
		super(p.getNombre(), p.getEdad(), p.getDni());//lo usaremos en el programa y cogeremos la informaci�n de persona
		this.aula = aula;
		
	}
	/*
	 * Caso hipotetico
	 * Persona pers = new Persona ("juan", "45", "65566666");
	 * 
	 */
	
	
	
	public Alumno(Persona p) {//super no esta vac�o lo coge der la clase persona y los demas atributos de la clase usuario los inicializo a nulo
		
		super(p.getNombre(), p.getEdad(), p.getDni());
		this.aula = null;
	
	}
	
	
	public Alumno() {
		
		super();   //super constructor al no tener getNombre,que coge la informaci�n de la clase persona,lo inicializo a vac�o porque me interesa
		this.aula = null;
		
	}

	
	
	public String getAula() {
		return aula;
	}


	public void setAula(String aula) {
		this.aula = aula;
	}


	public String getClase() {
		return aula;
	}

	public void setClase(String aula) {
		this.aula = aula;
	}

	

	@Override
	public String toString() {
		return "Alumno [aula=" + aula + ", datos basicos:" + super.toString() + "]";
	}


	//si lo hacemos no static podrimaos acceder al por ejemplo al alumno2 seria el invocador 
	public static Alumno addPersonas() {  //ojo al ser abstracta no podemos poner static
		Alumno user = new Alumno();// creas un objeto nuevo de tipo usuario constructor vacio
		Scanner teclado= new Scanner (System.in); 
		
		System.out.print("DAME EL NOMBRE " );   //clase persona
		//this.getNombre();  
	    user.setNombre(teclado.next());  
	    
	    System.out.print("DAME LA EDAD" );  //clase persona
	    user.setEdad(teclado.nextInt());
	    
	    System.out.print("DAME EL dni" );    //clase persona
	    user.setDni(teclado.next());
	    
	    System.out.print("DAME el aula" );    //atributo propio de alumno     
	    user.setAula(teclado.next());
		
		
	
		return user;
	}


	
	
	
	
	
	
	
	
	

}
