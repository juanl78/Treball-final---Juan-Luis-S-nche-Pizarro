package ClasesHeredadas;

import java.util.Scanner;

public class Trabajador extends Persona { // Trabajador = subclase, clase hija, clase heredera   Persona = superclase, clase maestra, clase padre
	private String numero;
	private String company;
	
	public Trabajador(String nombre, Integer edad, String dni, String numero, String company) {
		super(nombre, edad, dni);//esto ser�a para llamar al constructor de persona
		this.numero = numero;
		this.company = company;
	}

	// Trabajador trabajador1 = new Trabajador("juan", 27, "123456789j", "1234567890", "DAM");

	//creamos un constructor para Profesor pero en este los atributos relativos a Persona se los pasamos con un objeto de tipo Persona (Como si fuera un conjunto de datos)
	public Trabajador(Persona p,  String numero,String company) {	
		//(Persona p,=lleva los atributos de la clase persona.
		super(p.getNombre(), p.getEdad(), p.getDni());//lo usaremos en el programa y cogeremos la informaci�n de persona
		this.numero = numero;
		this.company = company;
	}

	
	//estro serviria para crear un trabajador a partir de una persona 
	// Trabajador trabajador1 = new Trabajador(new Persona ("juan", 27, "123456789j") "1234567890", "DAM");
	
	
	/*
	 * Caso hipotetico
	 * Persona pers = new Persona ("juan", "45", "65566666");
	 * 
	 */
	
	
	public Trabajador(Persona p) {//super no esta vac�o lo coge der la clase persona y los demas atributos de la clase usuario los inicializo a nulo
		
		super(p.getNombre(), p.getEdad(), p.getDni());
		this.numero = null;
		this.company = null;
	}
	
	
	public Trabajador() {
		
		super();   //super constructor al no tener getNombre,que coge la informaci�n de la clase persona,lo inicializo a vac�o porque me interesa
		this.numero = null;
		this.company = null;
	}


	
	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}


	@Override
	public String toString() {
		return "Trabajador [numero=" + numero + ", company=" + company + "datos basicos =" + super.toString() + "]";
	}

	//si lo hacemos no static podrimaos acceder al por ejemplo al alumno2 seria el invocador 
	public static Trabajador addPersonas() {  //ojo al ser abstracta no podemos poner static
		Trabajador user2 = new Trabajador();// creas un objeto nuevo de tipo usuario constructor vacio
		Scanner teclado= new Scanner (System.in); 
		
		System.out.print("DAME EL NOMBRE " ); 
		//this.getNombre();  
	    user2.setNombre(teclado.next());  
	    
	    System.out.print("DAME LA EDAD" );  
	    user2.setEdad(teclado.nextInt());
	    
	    System.out.print("DAME EL dni" );    
	    user2.setDni(teclado.next());
	    
	    System.out.print("DAME el numero" );         
	    user2.setNumero(teclado.next());
		
	    
	    System.out.print("DAME la compa�ia" );         
	    user2.setCompany(teclado.next());
		
	    
	    
	    
	
		return user2;
	}
	
	
}
