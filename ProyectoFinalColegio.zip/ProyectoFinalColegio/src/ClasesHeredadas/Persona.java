package ClasesHeredadas;

 public abstract class Persona { //cuando haces una clase abstracta no puedes crear un objeto de este tipo
    //alumno y profesor  hereda de persona  Una clase abstracta no puede ser instanciada, solo heredada.

	 //al poner abstract no pudes instanciar la clase persona directamente ,no puedes llamar al constructor con el new y crear tampoco un objeto de tipo Persona 
	 //directamente   Persona p=new Persona no puedes hacer el objeto
	private String nombre;
	private Integer edad;
	private String dni;
	
	public Persona(String nombre, Integer edad, String dni) {
		this.nombre = nombre;
		this.edad = edad;
		this.dni = dni;
	}
	
	public Persona() {
		
	}

	public String getNombre() {
		return this.nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Integer getEdad() {
		return edad;
	}
	public void setEdad(Integer edad) {
		this.edad = edad;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	

	@Override
	public String toString() {
		return " [nombre=" + nombre + ", edad=" + edad + ", dni=" + dni + "]";
	}
	
}
